﻿	function change_published_icon(icon, field){
		val=0;
		published_icon=$("#"+icon);
		if(published_icon.hasClass("glyphicon-check")){
			published_icon.removeClass("glyphicon-check");
			published_icon.addClass("glyphicon-unchecked");
			val=0;
			
		}else{
			published_icon.addClass("glyphicon-check");
			published_icon.removeClass("glyphicon-unchecked");
			val=1;
		}
		$("#"+field).val(val);
	}
	function is_published(id_icon, url){
		val=0;
		published_icon=$("#published_icon_"+id_icon);
		
		if(published_icon.hasClass("glyphicon-check")){
			published_icon.removeClass("glyphicon-check");
			published_icon.addClass("glyphicon-unchecked");
			message="This data is set to be unpublished.";
			val=0;
			
		}else{
			published_icon.addClass("glyphicon-check");
			published_icon.removeClass("glyphicon-unchecked");
			message="This data is set to be published.";
			val=1;
		}
		
		$.ajax({
			url: url+"/"+val,
			success: function(response)
			{
				//jQuery('#modal_ajax .modal-body').html(response);
				infomation_modal(message);
			}
		});
	}